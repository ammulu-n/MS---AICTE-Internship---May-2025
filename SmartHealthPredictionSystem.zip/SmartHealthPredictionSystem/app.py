from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)
model = pickle.load(open('model/health_model.pkl', 'rb'))

disease_info = {
    "Typhoid": {
        "precautions": "Drink clean water, rest, avoid spicy food",
        "doctor": "General Physician"
    },
    "Flu": {
        "precautions": "Rest, stay hydrated, take antiviral meds",
        "doctor": "General Physician"
    }
    # Add more diseases here
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    symptoms = [x for x in request.form.values()]
    input_data = np.zeros(5)  # Mock input vector length
    prediction = model.predict([input_data])[0]

    info = disease_info.get(prediction, {"precautions": "N/A", "doctor": "N/A"})
    return render_template('index.html', 
                           prediction_text=f"Disease: {prediction}",
                           precautions=info["precautions"],
                           doctor=info["doctor"])

if __name__ == "__main__":
    app.run(debug=True)
